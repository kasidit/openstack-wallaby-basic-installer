#!/bin/bash
numsmp="4"
memsize="8G"
etcloc=/srv/kasidit/openstackhosts/etc
imgloc=/srv/kasidit/openstackhosts/images/2Nodes
imgfile="compute.ovl"

storage1="disk1.img"
storage2="disk2.img"

#ovlloc=/home/kasidit/openstackhosts/images
#ovlfile="vm01.ovl"
exeloc="/srv/kasidit/qemu-kvm/bin"
#
#rm ${ovlloc}/${ovlfile}
#qemu-img create -f qcow2 -b ${imgloc}/${imgfile} ${ovlloc}/${ovlfile}
#
sudo ${exeloc}/qemu-system-x86_64 \
     -enable-kvm \
     -cpu host,kvm=off \
     -smp ${numsmp} \
     -m ${memsize} \
     -drive file=${imgloc}/${imgfile},format=qcow2 \
     -drive file=${imgloc}/${storage1},format=qcow2 \
     -drive file=${imgloc}/${storage2},format=qcow2 \
     -boot c \
     -vnc :94 \
     -qmp tcp::9446,server,nowait \
     -monitor tcp::6449,server,nowait \
     -netdev type=tap,script=${etcloc}/ovs-man-ifup,downscript=${etcloc}/ovs-man-ifdown,id=hostnet1 \
     -device virtio-net-pci,romfile=,netdev=hostnet1,mac=00:81:50:00:01:94 \
     -netdev type=tap,script=${etcloc}/ovs-data-ifup,downscript=${etcloc}/ovs-data-ifdown,id=hostnet2 \
     -device virtio-net-pci,romfile=,netdev=hostnet2,mac=00:81:50:00:02:94 \
     -netdev type=tap,script=${etcloc}/ovs-vlan-ifup,downscript=${etcloc}/ovs-vlan-ifdown,id=hostnet3 \
     -device virtio-net-pci,romfile=,netdev=hostnet3,mac=00:81:50:00:03:94 \
     -netdev type=tap,script=${etcloc}/ovs-man-ifup,downscript=${etcloc}/ovs-man-ifdown,id=hostnet4 \
     -device virtio-net-pci,romfile=,netdev=hostnet4,mac=00:81:50:00:04:94 \
     -rtc base=localtime,clock=vm 
