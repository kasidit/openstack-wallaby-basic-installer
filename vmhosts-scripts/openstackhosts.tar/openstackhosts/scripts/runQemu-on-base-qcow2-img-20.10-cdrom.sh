#!/bin/bash
numsmp="2"
memsize="4G"
isoloc=/srv/kasidit/openstackhosts/images/iso
imgloc=/srv/kasidit/openstackhosts/images/backup-ub20.10
imgfile="ubuntu20.10.img"
exeloc="/usr/bin"
#
#     -boot d -cdrom ${isoloc}/ubuntu-18.04.5-live-server-amd64.iso \
#
sudo ${exeloc}/qemu-system-x86_64 \
     -enable-kvm \
     -cpu host,kvm=off \
     -smp ${numsmp} \
     -m ${memsize} \
     -drive file=${imgloc}/${imgfile},format=qcow2 \
     -boot d -cdrom ${isoloc}/ubuntu-20.10-live-server-amd64.iso \
     -vnc :91 \
     -net nic \
     -net user 
