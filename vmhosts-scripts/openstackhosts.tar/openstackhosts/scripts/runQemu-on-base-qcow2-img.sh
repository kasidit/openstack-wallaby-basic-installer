#!/bin/bash
numsmp="2"
memsize="4G"
#isoloc=/srv/kasidit/openstackhosts/images
imgloc=/srv/kasidit/openstackhosts/images/backend-servers
imgfile="server.img"
exeloc="/usr/bin"
#
#     -net user,hostfwd=tcp::10022-:22  
#
sudo ${exeloc}/qemu-system-x86_64 \
     -enable-kvm \
     -cpu host,kvm=off \
     -smp ${numsmp} \
     -m ${memsize} \
     -drive file=${imgloc}/${imgfile},format=qcow2 \
     -boot c \
     -vnc :91 \
     -net nic \
     -net user  
     
