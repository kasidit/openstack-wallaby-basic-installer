#!/bin/bash
numsmp="4"
memsize="12G"
etcloc=/srv/kasidit/openstackhosts/etc
imgloc=/srv/kasidit/openstackhosts/images/victoria-4Nodes
imgfile="controller.ovl"
#ovlloc=/home/kasidit/openstackhosts/images/victoria-4Nodes
#ovlfile="vm01.ovl"
exeloc="/srv/kasidit/qemu-kvm/bin"
#
#rm ${ovlloc}/${ovlfile}
#qemu-img create -f qcow2 -b ${imgloc}/${imgfile} ${ovlloc}/${ovlfile}
#
sudo ${exeloc}/qemu-system-x86_64 \
     -enable-kvm \
     -cpu host,kvm=off \
     -smp ${numsmp} \
     -m ${memsize} \
     -drive file=${imgloc}/${imgfile},format=qcow2 \
     -boot c \
     -vnc :92 \
     -qmp tcp::9226,server,nowait \
     -monitor tcp::6229,server,nowait \
     -netdev type=tap,script=${etcloc}/ovs-man-ifup,downscript=${etcloc}/ovs-man-ifdown,id=hostnet1 \
     -device virtio-net-pci,romfile=,netdev=hostnet1,mac=00:81:50:00:01:92 \
     -rtc base=localtime,clock=vm 
