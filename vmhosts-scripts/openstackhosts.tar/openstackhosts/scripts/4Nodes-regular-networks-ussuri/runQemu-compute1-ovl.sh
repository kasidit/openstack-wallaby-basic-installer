#!/bin/bash
numsmp="4"
memsize="8G"
etcloc=/srv/kasidit/openstackhosts/etc
imgloc=/srv/kasidit/openstackhosts/images/ussuri-4Nodes
imgfile="compute1.ovl"
#ovlloc=/home/kasidit/openstackhosts/images/ussuri-4Nodes
#ovlfile="vm01.ovl"
exeloc="/srv/kasidit/qemu-kvm/bin"
#
#rm ${ovlloc}/${ovlfile}
#qemu-img create -f qcow2 -b ${imgloc}/${imgfile} ${ovlloc}/${ovlfile}
#
sudo ${exeloc}/qemu-system-x86_64 \
     -enable-kvm \
     -cpu host,kvm=off \
     -smp ${numsmp} \
     -m ${memsize} \
     -drive file=${imgloc}/${imgfile},format=qcow2 \
     -boot c \
     -vnc :95 \
     -qmp tcp::9556,server,nowait \
     -monitor tcp::6559,server,nowait \
     -netdev type=tap,script=${etcloc}/ovs-man-ifup,downscript=${etcloc}/ovs-man-ifdown,id=hostnet1 \
     -device virtio-net-pci,romfile=,netdev=hostnet1,mac=00:81:50:00:01:95 \
     -netdev type=tap,script=${etcloc}/ovs-data-ifup,downscript=${etcloc}/ovs-data-ifdown,id=hostnet2 \
     -device virtio-net-pci,romfile=,netdev=hostnet2,mac=00:81:50:00:02:95 \
     -netdev type=tap,script=${etcloc}/ovs-vlan-ifup,downscript=${etcloc}/ovs-vlan-ifdown,id=hostnet3 \
     -device virtio-net-pci,romfile=,netdev=hostnet3,mac=00:81:50:00:03:95 \
     -netdev type=tap,script=${etcloc}/ovs-man-ifup,downscript=${etcloc}/ovs-man-ifdown,id=hostnet4 \
     -device virtio-net-pci,romfile=,netdev=hostnet4,mac=00:81:50:00:04:95 \
     -rtc base=localtime,clock=vm 
