#!/bin/bash
numsmp="4"
memsize="4G"
etcloc=/srv/kasidit/openstackhosts/etc
imgloc=/srv/kasidit/openstackhosts/images/ussuri-4Nodes
imgfile="network.img"
#ovlloc=/home/kasidit/openstackhosts/images/ussuri-4Nodes
#ovlfile="vm01.ovl"
exeloc="/srv/kasidit/qemu-kvm/bin"
#
#rm ${ovlloc}/${ovlfile}
#qemu-img create -f qcow2 -b ${imgloc}/${imgfile} ${ovlloc}/${ovlfile}
#
sudo ${exeloc}/qemu-system-x86_64 \
     -enable-kvm \
     -cpu host,kvm=off \
     -smp ${numsmp} \
     -m ${memsize} \
     -drive file=${imgloc}/${imgfile},format=qcow2 \
     -boot c \
     -vnc :93 \
     -qmp tcp::9336,server,nowait \
     -monitor tcp::6339,server,nowait \
     -netdev type=tap,script=${etcloc}/ovs-man-ifup,downscript=${etcloc}/ovs-man-ifdown,id=hostnet1 \
     -device virtio-net-pci,romfile=,netdev=hostnet1,mac=00:81:50:00:01:93 \
     -netdev type=tap,script=${etcloc}/ovs-data-ifup,downscript=${etcloc}/ovs-data-ifdown,id=hostnet2 \
     -device virtio-net-pci,romfile=,netdev=hostnet2,mac=00:81:50:00:02:93 \
     -netdev type=tap,script=${etcloc}/ovs-vlan-ifup,downscript=${etcloc}/ovs-vlan-ifdown,id=hostnet3 \
     -device virtio-net-pci,romfile=,netdev=hostnet3,mac=00:81:50:00:03:93 \
     -netdev type=tap,script=${etcloc}/ovs-man-ifup,downscript=${etcloc}/ovs-man-ifdown,id=hostnet4 \
     -device virtio-net-pci,romfile=,netdev=hostnet4,mac=00:81:50:00:04:93 \
     -rtc base=localtime,clock=vm 
