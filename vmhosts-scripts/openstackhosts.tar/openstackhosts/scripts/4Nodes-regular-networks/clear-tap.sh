#!/bin/bash

sudo ovs-vsctl del-port tap0
sudo ovs-vsctl del-port tap1
sudo ovs-vsctl del-port tap2
sudo ovs-vsctl del-port tap3
sudo ovs-vsctl del-port tap4
sudo ovs-vsctl del-port tap5
sudo ovs-vsctl del-port tap6
sudo ovs-vsctl del-port tap7
sudo ovs-vsctl del-port tap8
sudo ovs-vsctl del-port tap9
sudo ovs-vsctl del-port tap10
sudo ovs-vsctl del-port tap11
sudo ovs-vsctl del-port tap12
