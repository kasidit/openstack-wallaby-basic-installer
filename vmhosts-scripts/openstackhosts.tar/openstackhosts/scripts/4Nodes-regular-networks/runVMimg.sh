./runQemu-compute1-img.sh &
./runQemu-compute-img.sh &
./runQemu-controller-img.sh &
./runQemu-network-img.sh &
