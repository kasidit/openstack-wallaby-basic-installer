./runQemu-compute1-ovl.sh &
./runQemu-compute-ovl.sh &
./runQemu-controller-ovl.sh &
./runQemu-network-ovl.sh &
