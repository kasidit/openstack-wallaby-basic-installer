qemu-img create -f qcow2 -b controller.img controller.ovl
qemu-img create -f qcow2 -b network.img network.ovl
qemu-img create -f qcow2 -b compute.img compute.ovl
qemu-img create -f qcow2 -b compute1.img compute1.ovl
