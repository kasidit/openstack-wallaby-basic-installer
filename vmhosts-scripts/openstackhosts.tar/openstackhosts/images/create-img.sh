#!/bin/bash

cp ubuntu20.10.img controller.img
cp ubuntu20.10.img network.img
cp ubuntu20.10.img compute.img
cp ubuntu20.10.img compute1.img
