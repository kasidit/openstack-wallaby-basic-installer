#!/bin/bash

qemu-img create -f qcow2 disk1.img 50G
qemu-img create -f qcow2 disk2.img 50G
