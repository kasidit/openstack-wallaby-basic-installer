#!/bin/bash

qemu-img commit controller.ovl
qemu-img commit network.ovl
qemu-img commit compute.ovl
qemu-img commit compute1.ovl
